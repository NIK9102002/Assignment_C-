﻿namespace Assignment1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("----- Welcome to Calculator -----");
                int choice = 0;
                do
                {
                    Console.WriteLine("Enter the Operand1 and Operand2");
                    double oper1 = Convert.ToDouble(Console.ReadLine());
                    double oper2 = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Choose the operation you want to perform?");
                    Console.WriteLine("1.Additon\n2.Subtraction\n3.Multiplication\n4.Divsion");
                    var operation = Console.ReadLine();
                    double result;
                    switch (operation)
                    {
                        case "1":
                            result = oper1 + oper2;
                            Console.WriteLine($"Result: {result}");
                            break;

                        case "2":
                            result = oper1 - oper2;
                            Console.WriteLine($"Result: {result}");
                            break;

                        case "3":
                            result = oper1 * oper2;
                            Console.WriteLine($"Result: {result}");                          
                            break;

                        case "4":
                            if (oper2 != 0)
                            {
                                result = oper1 / oper2;
                                Console.WriteLine($"Result: {result}");
                            }
                            else
                            {
                                Console.WriteLine("Cannot divide by zero.");
                            }
                            break;

                        default:
                            Console.WriteLine("Invalid operation.");
                            break;
                    }
                    Console.WriteLine("Do you want to continue? (Yes: 1; No: 0)");
                    choice = Convert.ToInt32(Console.ReadLine());
                } while (Convert.ToBoolean(choice));
                Console.WriteLine("-----Thank You-----");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error");
            }

        }
    }
}
