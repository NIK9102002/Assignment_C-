﻿namespace Assignment_2
{
    public interface IItem
    {
        string Name { get; }
        double Price { get; }
    }

    // Class representing an item
    public class Item : IItem
    {
        public string Name { get; }
        public double Price { get; }

        public Item(string name, double price)
        {
            Name = name;
            Price = price;
        }
    }
    public class Invoice
    {
        private List<(IItem item, int quantity)> items;

        public Invoice()
        {
            items = new List<(IItem, int)>();
        }

        // Method to add items to the invoice
        public void AddItem(IItem item, int quantity)
        {
            items.Add((item, quantity));
        }

        // Method to calculate and display the invoice
        public void GenerateInvoice()
        {
            double total = 0;

            Console.WriteLine("Invoice:");
            Console.WriteLine("---------------------------------------------------");
            foreach (var (item, quantity) in items)
            {
                double itemTotal = item.Price * quantity;
                total += itemTotal;
                Console.WriteLine($"{item.Name} - {quantity} x {item.Price:C} = {itemTotal:C}");
            }
            Console.WriteLine("---------------------------------------------------");
            Console.WriteLine($"Total: {total:C}");
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Item item1 = new Item("Item 1", 10.99);
            Item item2 = new Item("Item 2", 20.49);
            Item item3 = new Item("Item 3", 5.99);

            // Display available items
            Console.WriteLine("Available Items:");
            Console.WriteLine($"{item1.Name} - {item1.Price:C}");
            Console.WriteLine($"{item2.Name} - {item2.Price:C}");
            Console.WriteLine($"{item3.Name} - {item3.Price:C}");

            // Create invoice
            Invoice invoice = new Invoice();

            // User inputs items and quantity
            while (true)
            {
                Console.WriteLine("Enter item number (1, 2, 3) or 'done' to finish:");
                string input = Console.ReadLine().Trim().ToLower();

                if (input == "done")
                    break;

                int itemNumber;
                if (!int.TryParse(input, out itemNumber) || itemNumber < 1 || itemNumber > 3)
                {
                    Console.WriteLine("Invalid item number.");
                    continue;
                }

                Console.WriteLine("Enter quantity:");
                int quantity;
                if (!int.TryParse(Console.ReadLine(), out quantity) || quantity < 1)
                {
                    Console.WriteLine("Invalid quantity.");
                    continue;
                }

                // Add item to invoice
                switch (itemNumber)
                {
                    case 1:
                        invoice.AddItem(item1, quantity);
                        break;
                    case 2:
                        invoice.AddItem(item2, quantity);
                        break;
                    case 3:
                        invoice.AddItem(item3, quantity);
                        break;
                }
            }

            // Generate and display invoice
            invoice.GenerateInvoice();

        }
    }
}
